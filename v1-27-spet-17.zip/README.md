# Download or git clone the project 
# after git clone please use
npm install
or
sudo npm install
# After npm installed use 
grunt dev
# to run the project


# Else use the following comments to install angular js angm install locally
# USE THIS LINK TO CREATE ANGULAR JS 1 PROJECT CREATION
|||||||||||||||||||||||||||||||||||||||||||||||||||||
https://github.com/newaeonweb/generator-angm#readme||
|||||||||||||||||||||||||||||||||||||||||||||||||||||


# USE THIS COMMENTS TO CREATE THE NEW PROJECT ON ANGULAR JS_1
 # STEP-1
	# create a folder which you want to set your project
	# use the following comments to create the folder
mkdir [name of the project folder]
cd (name of the project folder)
   # STEP-2
	# Use the following comments to install Yeoman Generator
    # important if not works use sudo before the comment line 
npm install -g yo

npm install -g generator-angm

npm install -g bower-installer

yo angm

# STEP-3
	# Then set the app name inside the comment line it will ask.
	
# STEP-4
	# Finally run -----grunt dev---- to run the app


# spini-angular
# spini-get-spini
